<?php
/**
 * Google-style review card partial.
 *
 * Expects $args['review_index'] (int).
 *
 * @package Hausmeister_Theme
 */

defined( 'ABSPATH' ) || exit;

$i = isset( $args['review_index'] ) ? (int) $args['review_index'] : 0;

if ( $i < 1 || $i > 6 || ! hausmeister_review_is_visible( $i ) ) {
	return;
}

$name   = page_home( "review_{$i}_name" );
$date   = page_home( "review_{$i}_date" );
$rating = page_home( "review_{$i}_rating" );
$text   = page_home( "review_{$i}_text" );
$avatar = hausmeister_get_image_url( "review_{$i}_avatar" );
$color  = hausmeister_get_review_avatar_color( $name );
?>

<article class="g-review-card">
	<header class="g-review-card__header">
		<?php if ( $avatar ) : ?>
			<img
				class="g-review-card__avatar g-review-card__avatar--photo"
				src="<?php echo esc_url( $avatar ); ?>"
				alt=""
				width="40"
				height="40"
				loading="lazy"
			>
		<?php else : ?>
			<span class="g-review-card__avatar" style="background-color:<?php echo esc_attr( $color ); ?>">
				<?php echo esc_html( hausmeister_get_review_initial( $name ) ); ?>
			</span>
		<?php endif; ?>

		<div class="g-review-card__meta">
			<p class="g-review-card__name"><?php echo esc_html( $name ); ?></p>
			<div class="g-review-card__rating-row">
				<?php echo hausmeister_render_google_stars( $rating, 'sm' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php if ( $date ) : ?>
					<span class="g-review-card__date"><?php echo esc_html( $date ); ?></span>
				<?php endif; ?>
			</div>
		</div>

		<svg class="g-review-card__google-mark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="16" height="16" aria-hidden="true">
			<path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
			<path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
			<path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
			<path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
		</svg>
	</header>

	<p class="g-review-card__text"><?php echo esc_html( $text ); ?></p>
</article>
